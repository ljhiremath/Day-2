﻿using System;
using System.Collections;
using System.Linq;
using System.Text;

namespace Q17
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList empArrayList = new ArrayList();
            for (int i = 0; i < 4; i++)
            {
                employee objEmp = new employee();
                objEmp.SetEmployeeDetails();
                empArrayList.Add(objEmp);
            }

            foreach (employee item in empArrayList)
            {
                item.ShowEmployeeDetails();
            }

        }
    }
}
