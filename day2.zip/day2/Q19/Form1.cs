﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Q19
{
    public partial class Form1 : Form
    {
       
       
        public Form1()
        {
           
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
           string qry = "insert into product values(" + txtProdID.Text + ",'" + txtProdname.Text + "'," + txtUp.Text + "," + txtQty.Text + ")";
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
           DataSet ds = new DataSet();
           
            da.Fill(ds);
            MessageBox.Show("Row inserted successfully!");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
           string qry = "update product set ProductName = '" + txtProdname.Text + "',UnitPrice = " + txtUp.Text + " , Quantity = " + txtQty.Text + "where ProductID =" + txtProdID.Text ;
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
         DataSet ds = new DataSet();
            da.Fill(ds);
            MessageBox.Show("Row updated successfully!");

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "delete product where ProductID =" + txtProdID.Text;
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            MessageBox.Show("Row deleted successfully!");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnDisp_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "select * from product";
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
           
        }
    }
}
