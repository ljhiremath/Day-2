﻿namespace Q20
{
    partial class Generic_product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblProdId = new System.Windows.Forms.Label();
            this.lblProdname = new System.Windows.Forms.Label();
            this.lblUP = new System.Windows.Forms.Label();
            this.lblQty = new System.Windows.Forms.Label();
            this.txtProdID = new System.Windows.Forms.TextBox();
            this.tXTpRODNAME = new System.Windows.Forms.TextBox();
            this.txtUP = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.gvProd = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnDisp = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvProd)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(166, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "PRODUCT MANAGEMENT FORM";
            // 
            // lblProdId
            // 
            this.lblProdId.AutoSize = true;
            this.lblProdId.Location = new System.Drawing.Point(24, 76);
            this.lblProdId.Name = "lblProdId";
            this.lblProdId.Size = new System.Drawing.Size(53, 13);
            this.lblProdId.TabIndex = 1;
            this.lblProdId.Text = "ProductId";
            // 
            // lblProdname
            // 
            this.lblProdname.AutoSize = true;
            this.lblProdname.Location = new System.Drawing.Point(24, 112);
            this.lblProdname.Name = "lblProdname";
            this.lblProdname.Size = new System.Drawing.Size(75, 13);
            this.lblProdname.TabIndex = 2;
            this.lblProdname.Text = "Product Name";
            // 
            // lblUP
            // 
            this.lblUP.AutoSize = true;
            this.lblUP.Location = new System.Drawing.Point(35, 147);
            this.lblUP.Name = "lblUP";
            this.lblUP.Size = new System.Drawing.Size(52, 13);
            this.lblUP.TabIndex = 3;
            this.lblUP.Text = "Unit price";
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Location = new System.Drawing.Point(41, 180);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(46, 13);
            this.lblQty.TabIndex = 4;
            this.lblQty.Text = "Quantity";
            // 
            // txtProdID
            // 
            this.txtProdID.Location = new System.Drawing.Point(117, 76);
            this.txtProdID.Name = "txtProdID";
            this.txtProdID.Size = new System.Drawing.Size(100, 20);
            this.txtProdID.TabIndex = 5;
            // 
            // tXTpRODNAME
            // 
            this.tXTpRODNAME.Location = new System.Drawing.Point(117, 109);
            this.tXTpRODNAME.Name = "tXTpRODNAME";
            this.tXTpRODNAME.Size = new System.Drawing.Size(100, 20);
            this.tXTpRODNAME.TabIndex = 6;
            // 
            // txtUP
            // 
            this.txtUP.Location = new System.Drawing.Point(117, 140);
            this.txtUP.Name = "txtUP";
            this.txtUP.Size = new System.Drawing.Size(100, 20);
            this.txtUP.TabIndex = 7;
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(117, 173);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(100, 20);
            this.txtQty.TabIndex = 8;
            // 
            // gvProd
            // 
            this.gvProd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvProd.Location = new System.Drawing.Point(3, 335);
            this.gvProd.Name = "gvProd";
            this.gvProd.Size = new System.Drawing.Size(545, 150);
            this.gvProd.TabIndex = 9;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(12, 306);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(135, 306);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(265, 306);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(75, 23);
            this.btnDel.TabIndex = 12;
            this.btnDel.Text = "DELETE";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnDisp
            // 
            this.btnDisp.Location = new System.Drawing.Point(397, 306);
            this.btnDisp.Name = "btnDisp";
            this.btnDisp.Size = new System.Drawing.Size(75, 23);
            this.btnDisp.TabIndex = 13;
            this.btnDisp.Text = "DISPLAY";
            this.btnDisp.UseVisualStyleBackColor = true;
            this.btnDisp.Click += new System.EventHandler(this.btnDisp_Click);
            // 
            // Generic_product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 488);
            this.Controls.Add(this.btnDisp);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.gvProd);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.txtUP);
            this.Controls.Add(this.tXTpRODNAME);
            this.Controls.Add(this.txtProdID);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.lblUP);
            this.Controls.Add(this.lblProdname);
            this.Controls.Add(this.lblProdId);
            this.Controls.Add(this.label1);
            this.Name = "Generic_product";
            this.Text = "Generic_product";
            this.Load += new System.EventHandler(this.Generic_product_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvProd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblProdId;
        private System.Windows.Forms.Label lblProdname;
        private System.Windows.Forms.Label lblUP;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnDisp;
        public System.Windows.Forms.TextBox txtProdID;
        public System.Windows.Forms.TextBox tXTpRODNAME;
        public System.Windows.Forms.TextBox txtUP;
        public System.Windows.Forms.TextBox txtQty;
        public System.Windows.Forms.DataGridView gvProd;
    }
}