﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Q20
{
    public partial class Generic_product : Form
    {
        public Generic_product()
        {
            InitializeComponent();
        }

        public virtual void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "insert into product values(" + txtProdID.Text + ",'" + tXTpRODNAME.Text + "'," + txtUP.Text + "," + txtQty.Text + ")";
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();

            da.Fill(ds);
            MessageBox.Show("Row inserted successfully!");
        }

        public virtual void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "update product set ProductName = '" + tXTpRODNAME.Text + "',UnitPrice = " + txtUP.Text + " , Quantity = " + txtQty.Text + "where ProductID =" + txtProdID.Text;
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            MessageBox.Show("Row updated successfully!");

        }

        public virtual void btnDel_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "delete product where ProductID =" + txtProdID.Text;
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            MessageBox.Show("Row deleted successfully!");
        }

        public virtual void btnDisp_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "select * from product";
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvProd.DataSource = ds.Tables[0];

        }

        private void Generic_product_Load(object sender, EventArgs e)
        {

        }
    }
}
