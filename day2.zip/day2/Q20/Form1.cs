﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Q20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void unifiedShoppingHomeAPPToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void mOToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void genericPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Generic_product objGP = new Generic_product();
            objGP.Show();
        }

        private void mobileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Mobile objMob = new Mobile();
            objMob.Show();
        }

        private void smartPhoneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Smartphone objSP = new Smartphone();
            objSP.Show();
            
        }
    }
}
