﻿namespace Q20
{
    partial class Smartphone
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAV = new System.Windows.Forms.TextBox();
            this.txtMD = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(265, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Android version";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(268, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Memory Details";
            // 
            // txtAV
            // 
            this.txtAV.Location = new System.Drawing.Point(372, 82);
            this.txtAV.Name = "txtAV";
            this.txtAV.Size = new System.Drawing.Size(100, 20);
            this.txtAV.TabIndex = 17;
            // 
            // txtMD
            // 
            this.txtMD.Location = new System.Drawing.Point(372, 112);
            this.txtMD.Name = "txtMD";
            this.txtMD.Size = new System.Drawing.Size(100, 20);
            this.txtMD.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(78, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "SMARTPHONE";
            // 
            // Smartphone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 492);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtMD);
            this.Controls.Add(this.txtAV);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Name = "Smartphone";
            this.Text = "Smartphone";
            this.Load += new System.EventHandler(this.Smartphone_Load);
            this.Controls.SetChildIndex(this.txtProdID, 0);
            this.Controls.SetChildIndex(this.tXTpRODNAME, 0);
            this.Controls.SetChildIndex(this.txtUP, 0);
            this.Controls.SetChildIndex(this.txtQty, 0);
            this.Controls.SetChildIndex(this.txtCam, 0);
            this.Controls.SetChildIndex(this.txtMobilemod, 0);
            this.Controls.SetChildIndex(this.txtBatt, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.txtAV, 0);
            this.Controls.SetChildIndex(this.txtMD, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAV;
        private System.Windows.Forms.TextBox txtMD;
        private System.Windows.Forms.Label label7;
    }
}