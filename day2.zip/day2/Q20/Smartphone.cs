﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Q20
{
    public partial class Smartphone : Mobile
    {
        public Smartphone()
        {
            InitializeComponent();
        }

        private void Smartphone_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "insert into Smartphone values(" + txtProdID.Text + ",'" + tXTpRODNAME.Text + "'," + txtUP.Text + "," + txtQty.Text + ",'" + txtCam.Text + "','" + txtMobilemod.Text + "','" + txtBatt.Text + "','" + txtAV.Text + "','" + txtMD.Text + "')";
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();

            da.Fill(ds);
            MessageBox.Show("Row inserted successfully!");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "update Smartphone set ProductName = '" + tXTpRODNAME.Text + "',UnitPrice = " + txtUP.Text + " , Quantity = " + txtQty.Text + ",'" + txtCam.Text + "','" + txtMobilemod.Text + "','" + txtBatt.Text + "','" + txtAV.Text + "','" + txtMD.Text + "' where ProductID =" + txtProdID.Text;
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            MessageBox.Show("Row updated successfully!");

        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "delete Smartphone where ProductID =" + txtProdID.Text;
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            MessageBox.Show("Row deleted successfully!");
        }

        private void btnDisp_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "select * from Smartphone";
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvProd.DataSource = ds;
        }


    }
}
