﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Q22
{
    public partial class Product : System.Web.UI.Page
    {
        string cn = "Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
        string sqlcmd;
        SqlDataAdapter da;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            GridView1.Visible = true;
            sqlcmd = "select * from  product";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, cn);
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            string qry = "insert into product values(" + TxtProdId.Text + ",'" + txtProdname.Text + "'," + txtUP.Text + "," + txtQty.Text + ")";
             da = new SqlDataAdapter(qry, cn);
            ds = new DataSet();

            da.Fill(ds);
            Response.Write("Row inserted successfully!");
       
  }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "update product set ProductName = '" + txtProdname.Text + "',UnitPrice = " + txtUP.Text + " , Quantity = " + txtQty.Text + "where ProductID =" + TxtProdId.Text;
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            Response.Write("Row updated successfully!");
            //GridView1.DataSource = ds;
            //GridView1.DataBind();
           
        }

        protected void btnDel_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=XYZ;Integrated Security=True");
            string qry = "delete product where ProductID =" + TxtProdId.Text;
            SqlDataAdapter da = new SqlDataAdapter(qry, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            Response.Write("Row deleted successfully!");
            
           
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        
    }
}