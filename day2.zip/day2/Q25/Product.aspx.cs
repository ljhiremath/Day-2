﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Q22_Q25
{
    public partial class Product : System.Web.UI.Page
    {
        string sqlcon = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
        string sqlcmd;
        SqlDataAdapter da;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
          
            
            sqlcmd = "select * from  product";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
            gvProd.Datasource = ds.Tables[0];
            gvProd.DataBind();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            sqlcmd = "insert into product values (" + txtProductID.Text + ",'" + txtProductName.Text + "'," + txtUnitPrice.Text + "," + txtQuantity.Text + ")";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            sqlcmd = "update product set ProductId=" + txtProductID.Text + ",ProductName='" + txtProductName.Text + "', UnitPrice=" + txtUnitPrice.Text + ", Quantity=" + txtQuantity.Text + " where ProductId=" + txtProductID.Text ;

            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            sqlcmd = "delete from  product where ProductId=" + txtProductID.Text + "";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

    }
}