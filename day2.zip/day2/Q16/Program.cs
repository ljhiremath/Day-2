﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q16
{
    class Program
    {
        public static void GenericSwap<T>(ref T a, ref T b)
        {
            T c;
            c = a;
            a = b;
            b = c;
            Console.WriteLine("After swapping : a =" + a + "b =" + b);
        }

        static void Main(string[] args)
        {
            int a = 10, b = 20;
            Console.WriteLine("a =" + a + "b =" + b);
            GenericSwap<int>(ref a, ref b);
            Console.ReadKey();
        }
    }
}
