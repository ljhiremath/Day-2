﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q18
{
    class genemployee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string AccountName { get; set; }
        public int Salary { get; set; }

        public void SetEmployeeDetails()
        {
            Console.WriteLine("Enter 5 Employee details");

            Console.WriteLine("Enter Employee ID, Employee Name, Account Name, Salary");
            this.EmployeeID = Int32.Parse(Console.ReadLine());
            this.EmployeeName = Console.ReadLine();
            this.AccountName = Console.ReadLine();
            this.Salary = Int32.Parse(Console.ReadLine());

        }
        public void ShowEmployeeDetails()
        {
            Console.WriteLine("Employee ID : " + EmployeeID + " Employee Name : " + EmployeeName + " Account Name : " + AccountName + " Salary : " + Salary);
        }
    }
}
