﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q18
{
    class Program
    {
        static void Main(string[] args)
        {
            List<genemployee> empList = new List<genemployee>();
            for (int i = 0; i < 2; i++)
            {
                genemployee objEmp = new genemployee();
                objEmp.SetEmployeeDetails();
                empList.Add(objEmp);
            }

            foreach (genemployee item in empList)
            {
                item.ShowEmployeeDetails();
            }
        }
    }
}
